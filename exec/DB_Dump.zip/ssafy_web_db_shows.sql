-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: i9d203.p.ssafy.io    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	5.7.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shows`
--

DROP TABLE IF EXISTS `shows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shows` (
  `show_id` bigint(20) NOT NULL,
  `attendance_limit` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `max_attendance` int(11) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `show_progress` int(11) DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `category_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`show_id`),
  KEY `FKh29xykwjknd3u6db7wrgj7b1u` (`category_id`),
  KEY `FKl679k808pjimx5iv8tbtvnglk` (`user_id`),
  CONSTRAINT `FKh29xykwjknd3u6db7wrgj7b1u` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  CONSTRAINT `FKl679k808pjimx5iv8tbtvnglk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shows`
--

LOCK TABLES `shows` WRITE;
/*!40000 ALTER TABLE `shows` DISABLE KEYS */;
INSERT INTO `shows` VALUES (79,10,'2023-08-17','테스트 공연입니다.','2023-08-18 00:21:00.000000',15,0,1,'2023-08-17 23:21:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_img_height+(1).jpg','test',0,27),(80,10,'2023-08-17','','2023-08-18 23:22:00.000000',4,0,1,'2023-08-17 23:22:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_img_height+(1).jpg','테스트 공연',0,28),(81,10,'2023-08-18','','2023-08-19 02:31:00.000000',0,0,0,'2023-08-19 01:31:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/comedy_default_img_height+(1).jpg','예정된 공연',3,27),(82,10,'2023-08-19','','2023-08-19 23:03:00.000000',0,0,0,'2023-08-19 22:00:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/song_default_img_height2+(1).jpg','안녕하세요',2,33),(83,10,'2023-08-17','만나서 더러웠고 다신 보지 말자','2023-08-18 07:55:00.000000',0,0,2,'2023-08-18 05:55:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/song_default_img_height2+(1).jpg','피날레',2,33),(84,10,'2023-08-17','test test','2023-08-20 06:44:00.000000',0,0,2,'2023-08-18 06:44:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/1692276333349_jon-tyson-sMHVg2KBkLc-unsplash.jpg','test3',1,30),(85,10,'2023-08-18','test test','2023-08-20 06:47:00.000000',0,0,2,'2023-08-19 06:47:00.000000','https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/song_default_img_height2+(1).jpg','test4',2,30);
/*!40000 ALTER TABLE `shows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 22:07:05
