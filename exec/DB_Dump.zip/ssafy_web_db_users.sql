-- MySQL dump 10.13  Distrib 8.0.33, for macos13 (arm64)
--
-- Host: i9d203.p.ssafy.io    Database: ssafy_web_db
-- ------------------------------------------------------
-- Server version	5.7.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `banner_picture` varchar(255) DEFAULT NULL,
  `birthday` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `name` varchar(15) NOT NULL,
  `nickname` varchar(15) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(12) NOT NULL,
  `point` int(11) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `self_description` longtext,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_6dotkott2kjsp8vw4d0m25fb7` (`email`),
  UNIQUE KEY `UK_2ty1xmrrgtn89xt7kyxx6ta7h` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (27,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','2023-07-31','test@ssafy.com','M','test','test','$2a$10$EyrNusZgHvjr7Mv3PjjdSe42tQykUYPCCDgRxWxU1rx06wDHcO8JW','0000000000',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1),(28,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','2023-07-01','aaaa@ssafy.com','M','안녕','안녕','$2a$10$mka/ONxRn3HYfF1zYPYMHOYHPA9podVAkr7XlGQ2vi9wkR2Rj3d7q','01045457878',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/1692262635869_pikachu.png',NULL,1),(29,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','1994-12-02','hyunjin@ssafy.com','M','김현진','김현진','$2a$10$x0AVUCOM7GeTb3p3A9q3yOVGi3jamIHCH6YKneuJIk7szsEDPe0JK','01055467193',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1),(30,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/1692275639406_greyson-joralemon-9IBqihqhuHc-unsplash.jpg','1995-05-28','ninth6764@ssafy.com','M','구본재','koo','$2a$10$UXxwwKFZ0WTV8agGC.Tk3eOQ.tV4O0wEyvPcIz65tlv97PUYr.NJe','01046485654',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/1692275639223_profileimg.png',NULL,1),(31,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','1996-06-19','ssafy@ssafy.com','M','김싸피','ssafy','$2a$10$pABPyLE8rngjLCNpnOYmO.bkdchmix2YNU3oij3qh1Qmlakerw/HW','01012345678',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1),(32,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','2023-07-01','bbbb@ssafy.com','M','안녕하세용','안녕사에용','$2a$10$FmIZO0qqd.jATjBtw6Zd9O/5hPqVAt.kIo/EHrvZi.GkFh/jusQyu','01011112222',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1),(33,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','2023-07-19','wnwoghd22@gmail.com','M','Jay','Jay','$2a$10$qE1fM.Uxy/vgM3i4JG9WJ.nGren1ezDNRY3iryhxLnzQ80h2lCs/.','0000000000',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1),(34,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_banner+(1).jpg','1997-12-31','knuee2014@naver.com','M','구본재','Maru','$2a$10$syrmhDXa1IJMA42b6bOYTeyOYI0ExN2Rq6cahw6vPZlcy1cZu/P0S','01054584467',0,'https://ssafy-d203-bucket.s3.ap-northeast-2.amazonaws.com/default_profile.png',NULL,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-17 22:07:05
